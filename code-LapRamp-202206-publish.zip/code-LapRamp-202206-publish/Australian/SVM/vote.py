#bank.py
import pandas as pd 
from SVM import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

data = pd.read_csv(r'vote.csv')
print("该数据共有%d行，%d列。" % (data.shape[0],data.shape[1]))

#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.6,0.2,0.2)

print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train.drop('Y', axis=1)
X_train = np.array(X_train)
X_train = standarize(X_train)
y_train = train.iloc[:,train.columns == 'Y']
y_train  = np.array(y_train)
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)
np.random.seed(2)
#提取测试集特征和标签
X_test = test.drop('Y', axis=1)
X_test = np.array(X_test)
X_test = standarize(X_test)
y_test = test.iloc[:,test.columns == 'Y']
y_test = np.array(y_test)
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)
#提取验证集特征和标签
X_val = val.drop('Y', axis=1)
X_val = np.array(X_val)
X_val = standarize(X_val)
y_val = val.iloc[:,val.columns == 'Y']
y_val = np.array(y_val)
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)


def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] + X[i][1] + X[i][2] < -1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)

print("the number of  noisy y_train = 1：",np.sum(y_noise== 1))
print("the number of  noisy y_train = -1：",np.sum(y_noise == -1))

ratio =  (np.sum(y_train==1)-np.sum(y_noise==1))/np.sum(y_train==1)
print('噪声比例为：',ratio)


#75%
arg_kernel = {'name':'rbf','par':3.863291310137709} # kernel parameter
arg_model = {'gamma_A':0.00047469280451080344, 'gamma_I':0,'arg_kernel':arg_kernel,'t':2.25989729224750453}
arg_alg = {'maxIte':30}

#'gamma_I':17.563463184488622
# training
model,iteInf = train_ramp(X_train,y_noise,arg_model,arg_alg)


#验证集上准确率
classifier = model['f']
alpha = model['alpha']
y_pred =  classifier(X_val,alpha)  # predicted labels 
y_pred = np.array(y_pred)
y_pred = y_pred.reshape((len(y_val),1))
TP = np.sum( (y_pred ==1) & (y_val==1))
TN = np.sum( (y_pred ==-1) & (y_val==-1))
FP = np.sum( (y_pred ==1) & (y_val==-1))
FN = np.sum( (y_pred ==-1) & (y_val==1))
accuracy = (TP + TN)/(TP + TN + FP + FN)
P = TP/(TP + FP)
R = TP/(TP + FN)
F1 = 2*P*R/(P+R)
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
print('验证集准确率:',accuracy)
print('精确率：',P,'召回率：',R,'F1: ',F1)
#测试集上准确率
classifier = model['f']
alpha = model['alpha']
y_pred1 =  classifier(X_test,alpha)  # predicted labels 
y_pred1 = np.array(y_pred1)
y_pred1 = y_pred1.reshape((len(y_test),1))
TP = np.sum( (y_pred1 ==1) & (y_test==1))
TN = np.sum( (y_pred1 ==-1) & (y_test==-1))
FP = np.sum( (y_pred1 ==1) & (y_test==-1))
FN = np.sum( (y_pred1 ==-1) & (y_test==1))
accuracy1 = (TP + TN)/(TP + TN + FP + FN)
P = TP/(TP + FP)
R = TP/(TP + FN)
F1 = 2*P*R/(P+R)
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
print('测试集准确率:',accuracy1)
#训练集上准确率 
y_pred2 =   classifier(X_train,alpha)  # predicted labels 
y_pred2 = np.array(y_pred2)
y_pred2 = y_pred2.reshape((len(y_train),1))
TP1 = np.sum((y_pred2 ==1) & (y_train==1))
TN1 = np.sum( (y_pred2 ==-1) & (y_train==-1))
FP1 = np.sum( (y_pred2 ==1) & (y_train==-1))
FN1 = np.sum( (y_pred2 ==-1) & (y_train==1))
accuracy2 = (TP1 + TN1)/(TP1 + TN1 + FP1 + FN1)
print('训练集准确率:',accuracy2)

f = open('out1.txt','a+')
f.write('\n')
f.write('\n'+'噪声比例：'+ str(ratio))
f.write('\n'+'测试集accuracy: '+str(accuracy1)+'\n'+'对应的参数分别为: '+'\n'+str(arg_model))
f.write('\n'+'训练集accuracy: '+str(accuracy2)+'\t'+'验证集accuracy: '+str(accuracy))
f.close()
 