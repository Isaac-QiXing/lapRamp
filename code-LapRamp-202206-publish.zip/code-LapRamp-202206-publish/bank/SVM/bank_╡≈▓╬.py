#two_调参.py
import pandas as pd 
from SVM import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import random
import matplotlib.pyplot as plt
#读取数据
data = pd.read_csv(r'bank.csv')
print("该数据共有%d行，%d列。" % (data.shape[0],data.shape[1]))

#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.6,0.2,0.2)

print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train.drop('Y', axis=1)
X_train = np.array(X_train)
X_train = standarize(X_train)
y_train = train.iloc[:,train.columns == 'Y']
y_train  = np.array(y_train)
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)
np.random.seed(2)

#提取测试集特征和标签
X_test = test.drop('Y', axis=1)
X_test = np.array(X_test)
X_test = standarize(X_test)
y_test = test.iloc[:,test.columns == 'Y']
y_test = np.array(y_test)
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)

#提取验证集特征和标签
X_val = val.drop('Y', axis=1)
X_val = np.array(X_val)
X_val = standarize(X_val)
y_val = val.iloc[:,val.columns == 'Y']
y_val = np.array(y_val)
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)
#加非随机noisy label
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0.5:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)

print("the number of  noisy y_train = 1：",np.sum(y_noise== 1))
print("the number of  noisy y_train = -1：",np.sum(y_noise == -1))

ratio =  (np.sum(y_train==1)-np.sum(y_noise==1))/np.sum(y_train==1)
print('噪声比例为：',ratio)


def random_float_list(start, stop, length):
    start, stop = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.uniform(start, stop))
    return random_list
#cita_list = random_float_list(0,0.8,100)
gamma_A = random_float_list(0,0.01,100)
#gamma_I = random_float_list(1,40,100)
t = random_float_list(0,3,100)
par = random_float_list(0,4,100)
gamma = random_float_list(0,0.6,100)
lt_accuracy = []
for i in range (0,len(t)):
    arg_kernel = {'name':'rbf','par':par[i]} # kernel parameter
    arg_model = {'gamma_A':gamma_A[i], 'gamma_I':0, 'arg_kernel':arg_kernel, 't':t[i], 'gamma':gamma[i]}
    arg_alg = {'maxIte':30}
    #cita = cita_list[i]
    # training
    model,iteInf = train_ramp(X_train,y_noise,arg_model,arg_alg)

    #验证集上准确率
    classifier = model['f']
    alpha = model['alpha']
    y_pred =   classifier(X_val,alpha)  # predicted labels 
    #print(y_pred)
    TP = np.sum( (y_pred ==1) & (y_val==1))
    TN = np.sum( (y_pred ==-1) & (y_val==-1))
    FP = np.sum( (y_pred ==1) & (y_val==-1))
    FN = np.sum( (y_pred ==-1) & (y_val==1))
    accuracy = (TP + TN)/(TP + TN + FP + FN)
    lt_accuracy.append(accuracy)
max_accuracy_index = lt_accuracy.index(max(lt_accuracy))
print('accuracy:',max(lt_accuracy))
print('对应的参数分别为 gamma_A:{},t:{},par:{},gamma:{}'.format(gamma_A[max_accuracy_index], 
t[max_accuracy_index], par[max_accuracy_index], gamma[max_accuracy_index]))

f = open('out.txt','a+')
f.write('\n')
f.write('\n'+'噪声比例：'+ str(ratio))
f.write('\n'+'accuracy:'+str(max(lt_accuracy))+'\n'+'对应的参数分别为 gamma_A:{},t:{},par:{},gamma:{}'.format(gamma_A[max_accuracy_index],
t[max_accuracy_index], par[max_accuracy_index], gamma[max_accuracy_index]))
f.close()
