#two_调参.py
import pandas as pd 
from LapRamp import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import heapq
import random
import scipy.io as scio
dataFile = 'isolet.mat'
data = scio.loadmat(dataFile)
#print(data)
print(data['X'].shape)
XdataNew = 'X_data.mat'
scio.savemat(XdataNew, {'X':data['X']})
YdataNew = 'Y_data.mat'
scio.savemat(YdataNew, {'Y':data['Y']})
X = data['X']
X = np.array(X)
y = data['Y']
y = np.array(y)
data = np.hstack((X,y))
corr=np.around(np.corrcoef(data.T),decimals=3) #相关系数矩阵
s=corr[0,:]  #label和每个特征之间的相关系数


tmp = zip(range(len(s)), s)
large50 = heapq.nlargest(50, tmp, key=lambda x:x[1]) #找出50个最大的元素和对应的索引
#print(large50)  #Index and value of the largest 5 elements
res_list = [x[0] for x in large50]
#print(res_list)
#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.6,0.2,0.2)
print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train[:,:-1]
X_train = standarize(X_train)
y_train = train[:,-1]
y_train  = y_train.reshape((len(y_train),1))
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)



# #提取测试集特征和标签
X_test = test[:,:-1]
X_test = standarize(X_test)
y_test = test[:,-1]
y_test  = y_test.reshape((len(y_test),1))
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)

# #提取验证集特征和标签
X_val= test[:,:-1]
X_val = standarize(X_val)
y_val = val[:,-1]
y_val  = y_val.reshape((len(y_val),1))
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)

#加非随机noisy label
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            #-12.5，-6.5，
            if X[i][res_list[1]] + X[i][res_list[2]] + X[i][res_list[3]]  + X[i][res_list[4]]+ + X[i][res_list[5]] + X[i][res_list[6]] + X[i][res_list[7]] + X[i][res_list[8]]+ X[i][res_list[9]] + X[i][res_list[10]] + X[i][res_list[11]] + X[i][res_list[12]] + X[i][res_list[13]] + X[i][res_list[14]] + X[i][res_list[15]] + X[i][res_list[16]]< -12.5:
                noise[i] = -1         
            else:
                noise[i] = y[i]
                #-9
        elif X[i][res_list[1]] + X[i][res_list[2]] + X[i][res_list[3]]  + X[i][res_list[4]]+ + X[i][res_list[5]] + X[i][res_list[6]] + X[i][res_list[7]] + X[i][res_list[8]]+ X[i][res_list[9]] + X[i][res_list[10]] + X[i][res_list[11]] + X[i][res_list[12]] + X[i][res_list[13]] + X[i][res_list[14]] + X[i][res_list[15]] + X[i][res_list[16]]< -3:
                noise[i] = 1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)


#计算噪声比例
count1 = 0
count2  = 0
for i in range(len(y_train)):
    if y_train[i] == 1 and y_noise[i] == -1:
        count1 = count1 + 1
    elif y_train[i] == -1 and y_noise[i] == 1:
        count2  = count2 + 1
         
ratio1 =  count1/np.sum(y_train==1)
ratio2 =  count2/np.sum(y_train==-1)
print('正类噪声比例为：',ratio1,'负类噪声比例为：',ratio2)



def random_float_list(start, stop, length):
    start, stop = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.uniform(start, stop))
    return random_list


final_accuracy = []
max_accuracy = []
for i in range(10):
    gamma_A = random_float_list(0,0.1,100)
    gamma_I = random_float_list(1,40,100)
    t = random_float_list(0.1,4,100)
    par = random_float_list(0.5,5,100)
    gamma = random_float_list(0.1,2,100)
    cita_list = random_float_list(0.1,0.8,100)
    lt_accuracy = []
    for i in range (0,len(t)):
        arg_kernel = {'name':'rbf','par':par[i]} # kernel parameter
        arg_model = {'gamma_A':gamma_A[i], 'gamma_I':gamma_I[i],'arg_kernel':arg_kernel,'t':t[i],'gamma':gamma[i]}
        arg_alg = {'maxIte':30}
        cita = cita_list[i]
        # training
        model,iteInf = train_ramp(X_train,y_noise,arg_model,arg_alg,cita)

        #验证集上准确率
        classifier = model['f']
        alpha = model['alpha']
        y_pred =   classifier(X_val,alpha)   # predicted labels 
        #print(y_pred)
        TP = np.sum( (y_pred ==1) & (y_val==1))
        TN = np.sum( (y_pred ==-1) & (y_val==-1))
        FP = np.sum( (y_pred ==1) & (y_val==-1))
        FN = np.sum( (y_pred ==-1) & (y_val==1))
        accuracy = (TP + TN)/(TP + TN + FP + FN)
        lt_accuracy.append(accuracy)
    max_accuracy_index = lt_accuracy.index(max(lt_accuracy))
    max_accuracy.append(max(lt_accuracy))
    #print('accuracy:',max(lt_accuracy))

    datalist = [gamma_A[max_accuracy_index],gamma_I[max_accuracy_index],t[max_accuracy_index],par[max_accuracy_index],gamma[max_accuracy_index],cita_list[max_accuracy_index]]
#     for j in range(0,7):
#         sheet.write(i+1,j,datalist[j])
# savepath = 'C:/Users/Kelly/Desktop/结果.xls'
# result.save(savepath)

    arg_kernel = {'name':'rbf','par':datalist[3]} # kernel parameter
    arg_model = {'gamma_A':datalist[0], 'gamma_I':datalist[1],'arg_kernel':arg_kernel,'t':datalist[2],'gamma':datalist[4]}
    arg_alg = {'maxIte':30}
    cita = datalist[5]
    # training
    model,iteInf = train_ramp(X_train,y_noise,arg_model,arg_alg,cita)
    classifier = model['f']
    alpha = model['alpha']
    y_pred =   classifier(X_test,alpha)  # predicted labels 
    #print(y_pred)
    TP = np.sum( (y_pred ==1) & (y_test==1))
    TN = np.sum( (y_pred ==-1) & (y_test==-1))
    FP = np.sum( (y_pred ==1) & (y_test==-1))
    FN = np.sum( (y_pred ==-1) & (y_test==1))
    accuracy1 = (TP + TN)/(TP + TN + FP + FN)
    final_accuracy.append(accuracy1)
    print(datalist)
f = open('out.txt','a+')
f.write('\n')
f.write('\n'+'正类噪声比例为：'+str(ratio1)+'负类噪声比例为：'+ str(ratio2))

f.write('\n'+'平均accuracy为：'+ str(np.mean( final_accuracy))+'标准差为：'+str(np.std(final_accuracy)))