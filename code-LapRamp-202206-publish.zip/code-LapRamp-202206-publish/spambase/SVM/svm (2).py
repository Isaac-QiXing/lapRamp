#svm_batch_Eeg-eye-state.py

from sklearn.svm import SVC
import pandas as pd 
from SVM import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import random
import matplotlib.pyplot as plt
data = pd.read_csv(r'spambase.csv')
print("该数据共有%d行，%d列。" % (data.shape[0],data.shape[1]))

#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.4,0.3,0.3)

print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train.drop('Y', axis=1)
X_train = np.array(X_train)
X_train = standarize(X_train)
y_train = train.iloc[:,train.columns == 'Y']
y_train  = np.array(y_train)
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)
np.random.seed(2)

#提取测试集特征和标签
X_test = test.drop('Y', axis=1)
X_test = np.array(X_test)
X_test = standarize(X_test)
y_test = test.iloc[:,test.columns == 'Y']
y_test = np.array(y_test)
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)

#提取验证集特征和标签
X_val = val.drop('Y', axis=1)
X_val = np.array(X_val)
X_val = standarize(X_val)
y_val = val.iloc[:,val.columns == 'Y']
y_val = np.array(y_val)
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)
#print(X_train)
#加非随机noisy label
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            #-0.75，-0.45，-0.15
            if X[i][0] + X[i][1] + X[i][-1]< -0.45 :
                noise[i] = -1         
            else:
                noise[i] = y[i]
            #-0.83，-0.87，-0.79
        elif X[i][0] + X[i][1] + X[i][-1]< -0.87: 
            noise[i] = 1

        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)

#计算噪声比例
count1 = 0
count2  = 0
for i in range(len(y_train)):
    if y_train[i] == 1 and y_noise[i] == -1:
        count1 = count1 + 1
    elif y_train[i] == -1 and y_noise[i] == 1:
        count2  = count2 + 1
         
ratio1 =  count1/np.sum(y_train==1)
ratio2 =  count2/np.sum(y_train==-1)
print('正类噪声比例为：',ratio1,'负类噪声比例为：',ratio2)

clf = SVC(C=3, class_weight=None, coef0=0.0,
    decision_function_shape='ovr', degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False)
clf.fit(X_train, y_noise) 


#预测

y_pred = clf.predict(X_val)
y_pred = np.array(y_pred)
y_pred = y_pred.reshape((len(y_val),1))
#测试集上准确率
TP = np.sum( (y_pred ==1) & (y_val==1))
TN = np.sum( (y_pred ==-1) & (y_val==-1))
FP = np.sum( (y_pred ==1) & (y_val==-1))
FN = np.sum( (y_pred ==-1) & (y_val==1))
accuary = (TP + TN)/(TP + TN + FP + FN)
P = TP/(TP + FP)
R = TP/(TP + FN)
F1 = 2*P*R/(P+R)
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
print('测试集准确率:',accuary)
print('精确率：',P,'召回率：',R)
print('精确率：',P,'召回率：',R,'F1: ',F1)

#训练集上准确率 
y_pred1 = clf.predict(X_train)  
y_pred1 = np.array(y_pred1)
y_pred1 = y_pred1.reshape((len(y_train),1))
TP1 = np.sum( (y_pred1 ==1) & (y_train==1))
TN1 = np.sum( (y_pred1 ==-1) & (y_train==-1))
FP1 = np.sum( (y_pred1 ==1) & (y_train==-1))
FN1 = np.sum( (y_pred1 ==-1) & (y_train==1))
accuary1 = (TP1 + TN1)/(TP1 + TN1 + FP1 + FN1)
print('训练集准确率:',accuary1)

f = open('out.txt','a+')
f.write('\n')
f.write('\n'+str(ratio1)+'负类噪声比例为：'+ str(ratio2))
f.write('\n'+'测试集准确率:'+str(accuary))