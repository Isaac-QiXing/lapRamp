#two_调参.py
import pandas as pd 
from Ramp import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import random
import matplotlib.pyplot as plt
import xlwt
#读取数据
data = pd.read_csv(r'spambase.csv')
print("该数据共有%d行，%d列。" % (data.shape[0],data.shape[1]))

#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.4,0.3,0.3)

print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train.drop('Y', axis=1)
X_train = np.array(X_train)
X_train = standarize(X_train)
y_train = train.iloc[:,train.columns == 'Y']
y_train  = np.array(y_train)
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)
np.random.seed(2)

#提取测试集特征和标签
X_test = test.drop('Y', axis=1)
X_test = np.array(X_test)
X_test = standarize(X_test)
y_test = test.iloc[:,test.columns == 'Y']
y_test = np.array(y_test)
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)

#提取验证集特征和标签
X_val = val.drop('Y', axis=1)
X_val = np.array(X_val)
X_val = standarize(X_val)
y_val = val.iloc[:,val.columns == 'Y']
y_val = np.array(y_val)
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)
#加非随机noisy label
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            #-0.75
            if X[i][0] + X[i][1] + X[i][-1]< -0.15:
                noise[i] = -1         
            else:
                noise[i] = y[i]
            #-0.83
        elif X[i][0] + X[i][1] + X[i][-1]< -0.79: 
            noise[i] = 1

        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)

#计算噪声比例
count1 = 0
count2  = 0
for i in range(len(y_train)):
    if y_train[i] == 1 and y_noise[i] == -1:
        count1 = count1 + 1
    elif y_train[i] == -1 and y_noise[i] == 1:
        count2  = count2 + 1
         
ratio1 =  count1/np.sum(y_train==1)
ratio2 =  count2/np.sum(y_train==-1)
print('正类噪声比例为：',ratio1,'负类噪声比例为：',ratio2)

# result  = xlwt.Workbook(encoding='utf-8',style_compression=0)
# sheet = result.add_sheet('bank-38%',cell_overwrite_ok=True)
# col = ('noisy','gamma_A','gamma_I','t','par','accuracy')
# for i in range(0,6):
# 		sheet.write(0,i,col[i])

def random_float_list(start, stop, length):
    start, stop = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.uniform(start, stop))
    return random_list

max_accuracy = []
final_accuracy = []
for m in range(10):
    gamma_A = random_float_list(0,0.01,100)
    t = random_float_list(0,3,100)
    par = random_float_list(0,4,100)
    lt_accuracy = []
    for i in range (0,len(t)):
        arg_kernel = {'name':'rbf','par':par[i]} # kernel parameter
        arg_model = {'gamma_A':gamma_A[i], 'gamma_I':0, 'arg_kernel':arg_kernel, 't':t[i]}
        arg_alg = {'maxIte':30}
        #cita = cita_list[i]
        # training
        model,iteInf = train_ramp(X_train,y_noise,arg_model,arg_alg)
        
        #验证集上准确率
        classifier = model['f']
        alpha = model['alpha']
        y_pred =   classifier(X_val,alpha)  # predicted labels 
        #print(y_pred)
        TP = np.sum( (y_pred ==1) & (y_val==1))
        TN = np.sum( (y_pred ==-1) & (y_val==-1))
        FP = np.sum( (y_pred ==1) & (y_val==-1))
        FN = np.sum( (y_pred ==-1) & (y_val==1))
        accuracy = (TP + TN)/(TP + TN + FP + FN)
        lt_accuracy.append(accuracy)
    max_accuracy_index = lt_accuracy.index(max(lt_accuracy))
    max_accuracy.append(max(lt_accuracy))
    datalist = [gamma_A[max_accuracy_index],t[max_accuracy_index],par[max_accuracy_index]]
    arg_kernel = {'name':'rbf','par':datalist[2]} # kernel parameter
    arg_model = {'gamma_A':datalist[0], 'gamma_I':0,'arg_kernel':arg_kernel,'t':datalist[1]}
    arg_alg = {'maxIte':30}
#     for j in range(0,6):
#         sheet.write(m+1,j,datalist[j])
# savepath = 'C:/Users/DELL/Desktop/结果.xls'
# result.save(savepath)

#测试集上准确率
    classifier = model['f']
    alpha = model['alpha']
    y_pred =   classifier(X_test,alpha)  # predicted labels 
    #print(y_pred)
    TP = np.sum( (y_pred ==1) & (y_test==1))
    TN = np.sum( (y_pred ==-1) & (y_test==-1))
    FP = np.sum( (y_pred ==1) & (y_test==-1))
    FN = np.sum( (y_pred ==-1) & (y_test==1))
    accuracy1 = (TP + TN)/(TP + TN + FP + FN)
    final_accuracy.append(accuracy1)
f = open('out.txt','a+')
f.write('\n')
f.write('\n'+'正类噪声比例为：'+str(ratio1)+'负类噪声比例为：'+ str(ratio2))
f.write('\n'+'平均accuracy为：'+ str(np.mean( final_accuracy))+'标准差为：'+str(np.std(final_accuracy)))