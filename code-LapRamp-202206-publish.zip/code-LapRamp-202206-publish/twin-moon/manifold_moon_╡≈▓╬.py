  # demo_m_reg.py

from LapRamp import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import random

# load data 
fileName = 'moon_data.txt'
data_df = pd.read_table(fileName)
a = np.loadtxt(fileName)
X = a[:,[0,1]]
y = a[:,[-1]]
X = standarize(X)
y = y.reshape((len(y),1))

plt.scatter(X[:, 0], X[:, 1], s=40, c=np.squeeze(y), cmap=plt.cm.Spectral)
#plt.show()
#np.random.seed(111)
np.random.seed(1)
#加噪声
'''
def add_noise_y(y,yita):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if np.random.rand(1) < yita:
            if y[i]== -1:
                #noise[i] = 1
                noise[i]=-1
            else:
                noise[i] = -1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise

y_noise = add_noise_y(y,0.4)
'''
def add_noise_y(y):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y)
'''
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            # if X[i][0] < 0.5,0:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        #elif X[i][0] <-1.5,-1:
        elif X[i][0] > 0.5:
            noise[i] = 1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y,X)
'''


def random_float_list(start, stop, length):
    start, stop = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.uniform(start, stop))
    return random_list
gamma_A = random_float_list(0,0.1,400)
gamma_I = random_float_list(0,35,400)
t = random_float_list(0.1,3,400)
par = random_float_list(0.1,3,400)
gamma = random_float_list(0,3,400)
cita_list = random_float_list(0.2,0.8,400)
lt_accuracy = []
for i in range (0,len(t)):
    arg_kernel = {'name':'rbf','par':par[i]} # kernel parameter
    arg_model = {'gamma_A':gamma_A[i], 'gamma_I':gamma_I[i],'arg_kernel':arg_kernel,'t':t[i],'gamma':gamma[i]}
    arg_alg = {'maxIte':30}
    cita =0

    # training
    model,iteInf = train_ramp(X,y_noise,arg_model,arg_alg,cita)

    #测试集上准确率
    classifier = model['f']
    alpha = model['alpha']
    y_pred =   classifier(X,alpha)  # predicted labels 
    #print(y_pred)
    TP = np.sum( (y_pred ==1) & (y==1))
    TN = np.sum( (y_pred ==-1) & (y==-1))
    FP = np.sum( (y_pred ==1) & (y==-1))
    FN = np.sum( (y_pred ==-1) & (y==1))
    accuracy = (TP + TN)/(TP + TN + FP + FN)
    lt_accuracy.append(accuracy)
max_accuracy_index = lt_accuracy.index(max(lt_accuracy))
print('accuracy:',max(lt_accuracy))
print('对应的参数分别为 gamma_A:{},gamma_I：{}，t:{},par:{},gamma:{},cita:{}'.format(gamma_A[max_accuracy_index], gamma_I[max_accuracy_index], 
t[max_accuracy_index], par[max_accuracy_index], gamma[max_accuracy_index],cita_list[max_accuracy_index]))

'''
print('对应的参数分别为 gamma_A:{},gamma_I：{}，t:{},par:{}'.format(gamma_A[max_accuracy_index], gamma_I[max_accuracy_index], 
t[max_accuracy_index], par[max_accuracy_index]))
'''
