#SVM.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import svm
from code_manifold import *
fileName = 'moon_data.txt'
data_df = pd.read_table(fileName)
a = np.loadtxt(fileName)
X = a[:,[0,1]]
y = a[:,[-1]]
X = standarize(X)
y = y.reshape((len(y),1))
np.random.seed(1)

'''
#加非随机noisy label
def add_noise_y(y):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise

y_noise = add_noise_y(y)
'''
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            # if X[i][0] < 0.5,0:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        #elif X[i][0] <-1.5,-1:
        elif X[i][0] >0.5:
            noise[i] = 1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y,X)
'''

def add_noise_y(y,yita):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if np.random.rand(1) < yita:
            if y[i]== -1:
                #noise[i] = 1
                noise[i]= -1
            else:
                noise[i] = -1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise

y_noise = add_noise_y(y,0.4)
'''
def plot_2d_boundary(X, Y, predict_function, scale = 1, stride = 0.01, fig_size = (4, 3)):
    # X is a 2d array, covariates
    # Y is an 1d array, labels
    # predict_function maps an observation to a label
    # scale control the boundary of the plotq
    # stride is the step size along the axes
    # fig_size is the size of the figure
    x_min, x_max = X[:, 0].min() - scale, X[:, 0].max() + scale
    y_min, y_max = X[:, 1].min() - scale, X[:, 1].max() + scale
    # Produce the coordinates of the points will be predicted
    xx, yy = np.meshgrid(np.arange(x_min, x_max, stride), np.arange(y_min, y_max, stride))
    # Predict
    Z = predict_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.figure(1, figsize= fig_size)
    plt.pcolormesh(xx, yy, Z, cmap=plt.cm.Paired)
    plt.scatter(X[:, 0], X[:, 1], c=np.squeeze(Y), edgecolors='k', cmap=plt.cm.rainbow_r)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.show()


clf=svm.SVC()
'''
clf = svm.SVC(C=1, class_weight=None, coef0=0.0,
    decision_function_shape='ovr', degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False)
'''  
clf.fit(X, y_noise)

plot_2d_boundary(X, y_noise,lambda X: clf.predict(X), scale = 1, stride = 0.01, fig_size = (4, 3))
plt.show()