# LSVM_moonq.py

from LapRamp  import*
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import random

#import time
#start = time.clock()  #计算程序运行的时间

# load data 

# load data 
fileName = 'moon_data.txt'
data_df = pd.read_table(fileName)
a = np.loadtxt(fileName)
X = a[:,[0,1]]
y = a[:,[-1]]
X = standarize(X)
y = y.reshape((len(y),1))
plt.scatter(X[:, 0], X[:, 1], s=40, c=np.squeeze(y), cmap=plt.cm.Spectral)
#plt.show()
#np.random.seed(111)
np.random.seed(1)
#加噪声
print(np.sum(y == 1))
print(np.sum(y==-1))
'''
#加非随机noisy label
def add_noise_y(y):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise

y_noise = add_noise_y(y)
'''
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            # if X[i][0] < 0.5,0:
            if X[i][0] < 0.1:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        #elif X[i][0] <-1.5,-1:
        elif X[i][0] >2:
            noise[i] = 1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y,X)
'''
def add_noise_y(y,yita):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if np.random.rand(1) < yita:
            if y[i]== -1:
                #noise[i] = 1
                noise[i]=-1
            else:
                noise[i] = -1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise

y_noise = add_noise_y(y,0.4)
'''
# set model parameters 
arg_kernel = {'name':'rbf','par':0.4712367037554085} # kernel parameter
arg_model = {'gamma_A':0.022860531891387925, 'gamma_I':28,'arg_kernel':arg_kernel,'t':0.2228475686497735,'gamma': 1}
arg_alg = {'maxIte':50}
cita = 0.5
'''
# set model parameters 
arg_kernel = {'name':'rbf','par':1.0452234501902578} # kernel parameter
arg_model = {'gamma_A':0.0005996486895218034, 'gamma_I':1,'arg_kernel':arg_kernel,'t':0.13242210479839356}
arg_alg = {'maxIte':50}
'''
# training
model,iteInf = train_ramp(X,y_noise,arg_model,arg_alg,cita)

# 第二步 绘制决策边界
def plot_2d_boundary(X, Y, predict_function, scale = 1, stride = 0.01, fig_size = (4, 3)):
    # X is a 2d array, covariates
    # Y is an 1d array, labels
    # predict_function maps an observation to a label
    # scale control the boundary of the plotq
    # stride is the step size along the axes
    # fig_size is the size of the figure
    x_min, x_max = X[:, 0].min() - scale, X[:, 0].max() + scale
    y_min, y_max = X[:, 1].min() - scale, X[:, 1].max() + scale
    # Produce the coordinates of the points will be predicted
    xx, yy = np.meshgrid(np.arange(x_min, x_max, stride), np.arange(y_min, y_max, stride))
    # Predict
    Z = predict_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.figure(1, figsize= fig_size)
    plt.pcolormesh(xx, yy, Z, cmap=plt.cm.Paired)
    plt.scatter(X[:, 0], X[:, 1], c=np.squeeze(Y), edgecolors='k', cmap=plt.cm.rainbow_r)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.show()


# precision on train set 
classifier = model['f']
alpha = model['alpha']
y_pred =   classifier(X,alpha)  # predicted labels 
#print(y_pred)
TP = np.sum( (y_pred ==1) & (y==1))
TN = np.sum( (y_pred ==-1) & (y==-1))
FP = np.sum( (y_pred ==1) & (y==-1))
FN = np.sum( (y_pred ==-1) & (y==1))
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
accuracy = (TP + TN)/(TP + TN + FP + FN)
print('LRamp准确率：',accuracy)
plot_2d_boundary(X, y_noise,lambda X: classifier(X,alpha), scale = 1, stride = 0.01, fig_size = (4, 3))
