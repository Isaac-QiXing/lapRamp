#svm_batch_Eeg-eye-state.py

from sklearn.svm import SVC
import pandas as pd 
from SVM import *
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import random
import heapq
import random
#np.random.seed(2)
df= pd.read_csv(r'mnist.csv')
data = df.loc[:, (df != 0).any(axis=0)]


print("该数据共有%d行，%d列。" % (data.shape[0],data.shape[1]))

corr=np.around(np.corrcoef(data.T),decimals=3) #相关系数矩阵
#print(corr[0,:])
s=corr[0,:]  #label和每个特征之间的相关系数
'''
s1=np.delete(s,np.argmax(s),axis=0) #删除最大值1，按索引
a1=s1.max()#第二大值
s2=np.delete(s1,np.argmax(s1),axis=0) #删除第二大值，按索引
a2=s2.max() #第三大值
for I in range(len(s)):  #挑出最大两列
    if s[I]==a1:
        break
for J in range(len(s)):
    if s[J]==a2:
        break
print(I,J)
'''


tmp = zip(range(len(s)), s)
large50 = heapq.nlargest(50, tmp, key=lambda x:x[1]) #找出50个最大的元素和对应的索引
#print(large50)  #Index and value of the largest 5 elements
res_list = [x[0] for x in large50]
print(res_list)
#划分训练集 测试集和验证集
def train_test_val_split(df,ratio_train,ratio_test,ratio_val):
    train, middle = train_test_split(df,test_size=1-ratio_train,random_state=0)
    ratio=ratio_val/(1-ratio_train)
    test,validation =train_test_split(middle,test_size=ratio,random_state=0)
    return train,test,validation
    
train,test,val=train_test_val_split(data,0.6,0.2,0.2)

print('train.shape:',train.shape,'test.shape:',test.shape,'val.shape:',val.shape)

#提取训练集特征和标签
X_train = train.drop('Y', axis=1)
X_train = np.array(X_train)
X_train = standarize(X_train)
y_train = train.iloc[:,train.columns == 'Y']
y_train  = np.array(y_train)
print('X_train.shape:',X_train.shape,'y_train.shape:',y_train.shape)
np.random.seed(2)

#提取测试集特征和标签
X_test = test.drop('Y', axis=1)
X_test = np.array(X_test)
X_test = standarize(X_test)
y_test = test.iloc[:,test.columns == 'Y']
y_test = np.array(y_test)
print('X_test.shape:',X_test.shape,'y_test.shape:',y_test.shape)

#提取验证集特征和标签
X_val = val.drop('Y', axis=1)
X_val = np.array(X_val)
X_val = standarize(X_val)
y_val = val.iloc[:,val.columns == 'Y']
y_val = np.array(y_val)
print('X_val.shape:',X_val.shape,'y_val.shape:',y_val.shape)

#加非随机noisy label
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            #2.5,7.8
            if X[i][res_list[1]] + X[i][res_list[2]] + X[i][res_list[3]]  + X[i][res_list[4]]+ + X[i][res_list[5]] + X[i][res_list[6]] + X[i][res_list[7]] + X[i][res_list[8]]+ X[i][res_list[9]] + X[i][res_list[10]] + X[i][res_list[11]] + X[i][res_list[12]] + X[i][res_list[13]] + X[i][res_list[14]] + X[i][res_list[15]] + X[i][res_list[16]]< 7.8:
                noise[i] = -1         
            else:
                noise[i] = y[i]
            #-12
        elif X[i][res_list[1]] + X[i][res_list[2]] + X[i][res_list[3]]  + X[i][res_list[4]]+ + X[i][res_list[5]] + X[i][res_list[6]] + X[i][res_list[7]] + X[i][res_list[8]]+ X[i][res_list[9]] + X[i][res_list[10]] + X[i][res_list[11]] + X[i][res_list[12]] + X[i][res_list[13]] + X[i][res_list[14]] + X[i][res_list[15]] < -12.13:
                noise[i] = 1
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y_train,X_train)


#计算噪声比例
count1 = 0
count2  = 0
for i in range(len(y_train)):
    if y_train[i] == 1 and y_noise[i] == -1:
        count1 = count1 + 1
    elif y_train[i] == -1 and y_noise[i] == 1:
        count2  = count2 + 1
         
ratio1 =  count1/np.sum(y_train==1)
ratio2 =  count2/np.sum(y_train==-1)
print('正类噪声比例为：',ratio1,'负类噪声比例为：',ratio2)

clf = SVC(C=3, class_weight=None, coef0=0.0,
    decision_function_shape='ovr', degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False)
clf.fit(X_train, y_noise) 



#预测

y_pred = clf.predict(X_test)
y_pred = np.array(y_pred)
y_pred = y_pred.reshape((len(y_test),1))
#测试集上准确率
TP = np.sum( (y_pred ==1) & (y_test==1))
TN = np.sum( (y_pred ==-1) & (y_test==-1))
FP = np.sum( (y_pred ==1) & (y_test==-1))
FN = np.sum( (y_pred ==-1) & (y_test==1))
accuracy = (TP + TN)/(TP + TN + FP + FN)
P = TP/(TP + FP)
R = TP/(TP + FN)
F1 = 2*P*R/(P+R)
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
print('测试集准确率:',accuracy)
print('精确率：',P,'召回率：',R)
print('精确率：',P,'召回率：',R,'F1: ',F1)

#训练集上准确率 
y_pred1 = clf.predict(X_train)  
y_pred1 = np.array(y_pred1)
y_pred1 = y_pred1.reshape((len(y_train),1))
TP1 = np.sum( (y_pred1 ==1) & (y_train==1))
TN1 = np.sum( (y_pred1 ==-1) & (y_train==-1))
FP1 = np.sum( (y_pred1 ==1) & (y_train==-1))
FN1 = np.sum( (y_pred1 ==-1) & (y_train==1))
accuracy1 = (TP1 + TN1)/(TP1 + TN1 + FP1 + FN1)
print('训练集准确率:',accuracy1)

f = open('out.txt','a+')
f.write('\n')
f.write('\n'+'正类噪声比例为：'+str(ratio1)+'负类噪声比例为：'+ str(ratio2))

f.write('\n'+'平均accuracy为：'+ str(accuracy))