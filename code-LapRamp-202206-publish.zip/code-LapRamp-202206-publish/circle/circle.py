#circle.py
from sklearn.datasets.samples_generator import make_circles
import matplotlib.pyplot as plt
import numpy as np
from code_manifold import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import random
X,y=make_circles(n_samples=100,noise=0.05,factor=0.35,random_state=1)
print("X.shape:",X.shape)
X = standarize(X)
y[y==0] = -1

y = y.reshape((len(y),1))
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y,X)

ratio =  (np.sum(y==1)-np.sum(y_noise==1))/np.sum(y==1)
print('噪声比例为：',ratio)

def plot_2d_boundary(X, Y, predict_function, scale = 1, stride = 0.01, fig_size = (4, 3)):
    # X is a 2d array, covariates
    # Y is an 1d array, labels
    # predict_function maps an observation to a label
    # scale control the boundary of the plotq
    # stride is the step size along the axes
    # fig_size is the size of the figure
    x_min, x_max = X[:, 0].min() - scale, X[:, 0].max() + scale
    y_min, y_max = X[:, 1].min() - scale, X[:, 1].max() + scale
    # Produce the coordinates of the points will be predicted
    xx, yy = np.meshgrid(np.arange(x_min, x_max, stride), np.arange(y_min, y_max, stride))
    # Predict
    Z = predict_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.figure(1, figsize= fig_size)
    plt.pcolormesh(xx, yy, Z, cmap=plt.cm.Paired)
    plt.scatter(X[:, 0], X[:, 1], c=np.squeeze(Y), edgecolors='k', cmap=plt.cm.rainbow_r)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.show()


'''
unique_lables=set(labels)
colors=plt.cm.Spectral(np.linspace(0,1,len(unique_lables)))
for k,col in zip(unique_lables,colors):
    x_k=X[labels==k]
    plt.plot(x_k[:,0],x_k[:,1],'o',markerfacecolor=col,markeredgecolor="k",
             markersize=10)
plt.title('data by make_moons()')
plt.show()
'''

arg_kernel = {'name':'rbf','par':0.7498695437289673} # kernel parameter
arg_model = {'gamma_A':0.0051289206258490995, 'gamma_I':0,'arg_kernel':arg_kernel,'t':0.27465956274103975,'gamma':0.6791716544403801}
arg_alg = {'maxIte':30}
cita=0.44347358765307565

#gamma_A:0.0051289206258490995,gamma_I：24.380491211406433，t:0.27465956274103975,par:0.5899056760016355,gamma:0.6791716544403801,cita:0.44347358765307565


# training
model,iteInf = train_ramp(X,y_noise,arg_model,arg_alg,cita)



# precision on train set 
classifier = model['f']
alpha = model['alpha']
y_pred =   classifier(X,alpha)  # predicted labels 

TP = np.sum( (y_pred ==1) & (y==1))
TN = np.sum( (y_pred ==-1) & (y==-1))
FP = np.sum( (y_pred ==1) & (y==-1))
FN = np.sum( (y_pred ==-1) & (y==1))
print('TP:',TP,'TN:',TN,'FP:',FP,'FN:',FN)
accuracy = (TP + TN)/(TP + TN + FP + FN)
print('LRamp准确率：',accuracy)
plt.xlabel('gamma_A = 0.005 , gamma_I = 20')
plt.title(' 80% noisy label')
plot_2d_boundary(X, y_noise,lambda X: classifier(X,alpha), scale = 1, stride = 0.01, fig_size = (4, 3))









    
