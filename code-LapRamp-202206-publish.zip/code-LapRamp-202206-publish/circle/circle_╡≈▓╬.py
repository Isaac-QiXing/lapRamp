#circle.py
from sklearn.datasets.samples_generator import make_circles
import matplotlib.pyplot as plt
import numpy as np
from code_manifold import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import random
X,y = make_circles(n_samples=100,noise=0.05,factor=0.35,random_state=1)
X = standarize(X)
print("X.shape:",X.shape)

y[y==0] = -1
y = y.reshape((len(y),1))
def add_noise_y(y,X):
    m,n = y.shape
    noise = np.zeros([m,n])
    for i in range(m):
        if y[i] == 1:
            if X[i][0] < 0.5:
                noise[i] = -1         
            else:
                noise[i] = y[i]
        else:
            noise[i] = y[i]
    noise = np.array(noise)
    return noise
y_noise = add_noise_y(y,X)

def plot_2d_boundary(X, Y, predict_function, scale = 1, stride = 0.01, fig_size = (4, 3)):
    # X is a 2d array, covariates
    # Y is an 1d array, labels
    # predict_function maps an observation to a label
    # scale control the boundary of the plotq
    # stride is the step size along the axes
    # fig_size is the size of the figure
    x_min, x_max = X[:, 0].min() - scale, X[:, 0].max() + scale
    y_min, y_max = X[:, 1].min() - scale, X[:, 1].max() + scale
    # Produce the coordinates of the points will be predicted
    xx, yy = np.meshgrid(np.arange(x_min, x_max, stride), np.arange(y_min, y_max, stride))
    # Predict
    Z = predict_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    plt.figure(1, figsize= fig_size)
    plt.pcolormesh(xx, yy, Z, cmap=plt.cm.Paired)
    plt.scatter(X[:, 0], X[:, 1], c=np.squeeze(Y), edgecolors='k', cmap=plt.cm.rainbow_r)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.show()


'''
unique_lables=set(labels)
colors=plt.cm.Spectral(np.linspace(0,1,len(unique_lables)))
for k,col in zip(unique_lables,colors):
    x_k=X[labels==k]
    plt.plot(x_k[:,0],x_k[:,1],'o',markerfacecolor=col,markeredgecolor="k",
             markersize=10)
plt.title('data by make_moons()')
plt.show()
'''

def random_float_list(start, stop, length):
    start, stop = (float(start), float(stop)) if start <= stop else (float(stop), float(start))
    length = int(abs(length)) if length else 0
    random_list = []
    for i in range(length):
        random_list.append(random.uniform(start, stop))
    return random_list

gamma_A = random_float_list(0,0.01,200)
gamma_I = random_float_list(1,40,200)
t = random_float_list(0.1,3,200)
par = random_float_list(0.1,3,200)
gamma = random_float_list(0.1,3,200)
cita_list = random_float_list(0.1,0.7,200)
lt_accuracy = []
for i in range (0,len(t)):
    arg_kernel = {'name':'rbf','par':par[i]} # kernel parameter
    arg_model = {'gamma_A':gamma_A[i], 'gamma_I':0,'arg_kernel':arg_kernel,'t':t[i],'gamma':gamma[i]}
    arg_alg = {'maxIte':30}
    cita = cita_list[i]

    # training
    model,iteInf = train_ramp(X,y_noise,arg_model,arg_alg,cita)

    #测试集上准确率
    classifier = model['f']
    alpha = model['alpha']
    y_pred =   classifier(X,alpha)  # predicted labels 
    #print(y_pred)
    TP = np.sum( (y_pred ==1) & (y==1))
    TN = np.sum( (y_pred ==-1) & (y==-1))
    FP = np.sum( (y_pred ==1) & (y==-1))
    FN = np.sum( (y_pred ==-1) & (y==1))
    accuracy = (TP + TN)/(TP + TN + FP + FN)
    lt_accuracy.append(accuracy)
max_accuracy_index = lt_accuracy.index(max(lt_accuracy))
print('accuracy:',max(lt_accuracy))
'''
print('对应的参数分别为 gamma_A:{},gamma_I：{}，t:{},par:{},gamma:{}'.format(gamma_A[max_accuracy_index], gamma_I[max_accuracy_index], 
t[max_accuracy_index], par[max_accuracy_index], gamma[max_accuracy_index]))
'''

print('对应的参数分别为 gamma_A:{},gamma_I：{}，t:{},par:{},gamma:{},cita:{}'.format(gamma_A[max_accuracy_index], gamma_I[max_accuracy_index], 
t[max_accuracy_index], par[max_accuracy_index], gamma[max_accuracy_index],cita_list[max_accuracy_index]))







    
